# YAF Voice Kit — elektron darsliklar uchun ovozli tizim

Bu to‘plam “Yarimo‘tkazgich asboblar fizikasi” va “Fizpraktikum” elektron darsliklarida ishlayotgan ovozli tizimning ko‘chma versiyasi. Muallif: I.M. Eshboltayev, QDU.

| Fayl | Mazmuni |
|---|---|
| **INTEGRATSIYA.md** | Agent yoki dasturchi uchun to‘liq joriy etish qo‘llanmasi |
| **CLAUDE_CODE_PROMPT.md** | Claude Code’ga beriladigan tayyor prompt |
| `js/yaf-voice.js`, `css/yaf-voice.css` | Tizimning o‘zi |
| `js/alifbo.js` | Faqat yangi alifbodagi saytlar uchun |
| `tools/tts_extract.py`, `tools/tts_generate.py`, `.github/workflows/ovoz.yml` | O‘zbekcha neyron MP3 generatsiyasi (API kalitsiz) |
| `tools/voice_check.py` | Integratsiyani avtomatik tekshirish |
| `namuna-maruza.html`, `namuna-laboratoriya.html` | Ishlaydigan namunalar |

**Namunani ko‘rish:**

```bash
python3 -m http.server 8000
```

So‘ng brauzerda `http://localhost:8000/namuna-maruza.html` ni oching.

Namunalarda MP3 yo‘q, shuning uchun brauzer ovozi eshitiladi. MP3 lar GitHub Actions orqali yaratiladi.

Litsenziya: CC BY-SA 4.0.
