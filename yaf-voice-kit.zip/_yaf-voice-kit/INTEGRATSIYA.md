# YAF Voice — ovozli tizimni elektron darslikka joriy etish qo‘llanmasi

> **Kim uchun:** maqsadli elektron darslik repozitoriyasida ishlaydigan AI agent (Claude Code) yoki dasturchi.
> **Maqsad:** “Yarimo‘tkazgich asboblar fizikasi” va “Fizpraktikum” darsliklarida ishlayotgan ovoz tizimini boshqa darslikning **barcha ma’ruza va laboratoriya sahifalariga** xuddi o‘sha sifatda joriy qilish.
> **Asl loyihalar (namuna sifatida o‘rganish mumkin):**
> <https://github.com/eshboltayev/Yarimo-tkazgich_asboblar_fizikasi>, <https://github.com/eshboltayev/Fizpraktikum>

---

## 1. Tizim nima qiladi

| Imkoniyat | Qanday ishlaydi |
|---|---|
| **“Tinglash” tugmasi** (har bir ma’ruza/laboratoriya sarlavhasida) | Sarlavhadan boshlab belgilangan bo‘limlarni xatboshma-xatboshi o‘qiydi. O‘qilayotgan xatboshi havorang ramka bilan belgilanadi va ekran markaziga suriladi. |
| **O‘qish paneli** (pastda) | Pauza / davom etish, oldingi va keyingi xatboshi, to‘xtatish, “24 / 39” holat ko‘rsatkichi. **Esc** — to‘xtatish. |
| **“Shu yerdan o‘qish”** | Istalgan xatboshini bosish yetarli: uning ustida tugma paydo bo‘ladi, bosilsa o‘qish o‘sha joydan boshlanadi. O‘qituvchi to‘xtatib, o‘z fikrini aytib, davom ettira oladi. |
| **O‘zbekcha neyron ovoz** | Har bir xatboshi uchun oldindan tayyorlangan MP3 fayllar ishlatiladi (Microsoft Edge ovozi: Sardor yoki Madina). Telefon, kompyuter va elektron doskada **bir xil, tabiiy ovoz** eshitiladi, qurilmadagi ovozga bog‘liq emas. |
| **Formulalarni odamdek o‘qish** | KaTeX/MathJax formulalari TeX manbasidan so‘zga aylantiriladi. Masalan: `10¹⁶ sm⁻³` → “10 ning 16-darajasi, santimetr ning minus 3-darajasi”, `0,77 V` → “0 butun yuzdan 77 volt”, `V_bi = kT/q` → “ve bi teng ka te bo‘lingan ku”, `MDYa` → “em-de-ya”, `Om·m` → “om-metr”. |
| **RU / EN** | Sayt Google Translate orqali tarjima qilinganda brauzerning o‘z ovozi ishlatiladi (Chrome va Edge’da sifatli Google/Microsoft ovozlari bor). |
| **Virtual laboratoriyada “Ovozli namoyish”** | Model parametrlarini o‘zi silliq o‘zgartiradi, har bir qadamni ovozda tushuntiradi va natijalar panelini yoritadi. Oxirida boshqaruv talabaga o‘tadi. |
| **Zaxira** | MP3 hali tayyor bo‘lmasa, brauzer ovozi ishlatiladi. O‘zbekcha ovoz bo‘lmasa, turkcha ovoz va ogohlantirish chiqadi. |

**API kalit, server yoki to‘lov kerak emas.** MP3 fayllar GitHub Actions’da avtomatik yaratilib, repozitoriyga saqlanadi.

---

## 2. Arxitektura

```
 ┌──────────────── Brauzer (har bir sahifa) ────────────────┐
 │  css/yaf-voice.css   js/yaf-voice.js   [js/alifbo.js]    │
 │     │                    │                               │
 │     │      textOf(el) → tex2words → normUz → h32(xesh)   │
 │     │                    │                               │
 │     │      audio/uz/manifest.json da xesh bormi?         │
 │     │         ├─ ha  → audio/uz/<xesh>.mp3 ni ijro etish  │
 │     │         └─ yo‘q → speechSynthesis (brauzer ovozi)   │
 └──────────────────────────────────────────────────────────┘
 ┌──────────── GitHub Actions (.github/workflows/ovoz.yml) ───────────┐
 │ push → tools/tts_extract.py: saytni headless Chromium’da ochadi va │
 │        window.YAF_TTS.items() orqali AYNAN brauzer o‘qiydigan       │
 │        matnlarni va ularning xeshini oladi → audio/uz/texts.json    │
 │      → tools/tts_generate.py: edge-tts bilan faqat yangi matnlarni  │
 │        MP3 qiladi, eskilarini o‘chiradi → audio/uz/manifest.json    │
 │      → commit + push (audio/uz/)                                    │
 └────────────────────────────────────────────────────────────────────┘
```

**Asosiy g‘oya:** MP3 fayl nomi — matnning FNV-1a xeshi. Bu matnni brauzer va generator **bitta JS funksiya** bilan hisoblaydi. Shuning uchun ular hech qachon farq qilmaydi. Matn o‘zgarsa, xesh ham o‘zgaradi: yangi MP3 yaratiladi, eskisi o‘chiriladi.

---

## 3. To‘plam tarkibi

| Fayl | Vazifasi | Qayerga ko‘chiriladi |
|---|---|---|
| `js/yaf-voice.js` | Butun ovoz tizimi (o‘qish, panel, MP3, formulalar, namoyish). Mustaqil, hech narsaga bog‘liq emas. | Saytning JS papkasiga |
| `css/yaf-voice.css` | Tugma, ramka, panel, namoyish izohi uslublari (qorong‘i va yorug‘ rejim) | Saytning CSS papkasiga |
| `js/alifbo.js` | **Faqat sayt yangi o‘zbek alifbosida bo‘lsa** (Ö, Ğ, Ş, Ç): ovoz uchun matnni eski imloga qaytaradi | Shart bilan (5.2-bandga qarang) |
| `tools/tts_extract.py` | Matnlarni yig‘adi (headless Chromium) | Repozitoriy ildizidagi `tools/` papkasiga |
| `tools/tts_generate.py` | MP3 yaratadi (edge-tts) | `tools/` |
| `tools/voice_check.py` | Integratsiyani tekshiradi (tugmalar, bo‘limlar, namoyish kalitlari) | `tools/` |
| `.github/workflows/ovoz.yml` | Avtomatik MP3 generatsiyasi | `.github/workflows/` |
| `namuna-maruza.html`, `namuna-laboratoriya.html`, `js/namuna-model.js` | Ishlaydigan minimal namunalar — HTML shartnomasini ko‘rish uchun | Ko‘chirilmaydi (faqat o‘rganish uchun) |

---

## 4. Integratsiyadan oldin: loyihani tahlil qilish (majburiy)

Agent avval quyidagilarni aniqlab, qisqa hisobot yozishi kerak:

1. **Texnologiya.** Sayt qanday quriladi?
   - Toza statik HTML;
   - Python yoki Node generator (shablonlar);
   - Jekyll, Hugo, Docusaurus, VitePress, Next.js, React SPA va hokazo.

   Qaysi fayl yoki shablon **ma’ruza** sahifasini, qaysi biri **laboratoriya** sahifasini hosil qiladi? Agar generator bo‘lsa, o‘zgarish **shablonga** kiritiladi, yaratilgan HTML ga emas.
2. **Nashr qilinadigan papka.** GitHub Pages qaysi papkadan beriladi (`/`, `docs/`, `dist/`, `build/`, `_site/`)? Statik fayllar (`public/`, `static/`) qayerda?
3. **Formulalar.** Qaysi vosita ishlatiladi: KaTeX, MathJax 3, MathJax 2 yoki rasm? KaTeX’da MathML chiqishi (`output: 'htmlAndMathml'` — standart) **o‘chirilmagan bo‘lishi** kerak, chunki ovoz TeX’ni shundan oladi.
4. **Alifbo.** Matnlar eski lotin imlosida (o‘, g‘, sh, ch) yoki yangi alifboda (ö, ğ, ş, ç)?
5. **Til.** Sayt ko‘p tillimi? Google Translate ishlatilganmi (`googtrans` cookie)? `<html lang>` qiymati qanday?
6. **Sahifa tuzilishi.** Ma’ruza va laboratoriya sahifalarida qaysi bo‘limlar bor va ularning `id` lari qanday? Masalan: maqsad, reja, nazariya, misol, xatolar, test, adabiyot. `id` bo‘lmasa, qo‘shish kerak.
7. **Virtual laboratoriyalar.** Qanday qurilgan: o‘z JS modellari (canvas + slayderlar), iframe (PhET) yoki umuman yo‘q? Boshqaruv elementlari (`input[type=range]`, `select`) qayerda yaratiladi?
8. **Mavjud ovoz yoki tugmalar.** Konflikt bo‘lmasligi uchun tekshiring: `.voice-btn`, `.reading`, `.hero-tools`, `.tour-*`, `.yaf-*` klasslari, `speechSynthesis` ishlatilishi.

---

## 5. Integratsiya qadamlari

### 5.1. Fayllarni ko‘chirish

- `js/yaf-voice.js` → saytning JS papkasi. **Muhim:** skript sayt ildizidan bir papka ichida bo‘lsa (`<ildiz>/js/yaf-voice.js`), audio papkasi avtomatik `<ildiz>/audio/uz/` deb aniqlanadi. Boshqa joyda bo‘lsa, `window.YAF_VOICE = { root: '...', audioBase: '...' }` bilan ko‘rsating (5.8-band).
- `css/yaf-voice.css` → CSS papkasi. Ranglarni saytning dizayniga moslang, klass nomlarini o‘zgartirmang.
- `tools/*.py` → repozitoriy ildizidagi `tools/`.
- `.github/workflows/ovoz.yml` → `.github/workflows/`. Undagi `env` blokini sozlang (5.7-band).

### 5.2. Har bir ma’ruza va laboratoriya sahifasiga ulash

`<head>` ichiga:

```html
<link rel="stylesheet" href="css/yaf-voice.css">
```

`</body>` dan oldin (KaTeX skriptlaridan **keyin**):

```html
<!-- Sayt YANGI alifboda bo‘lsa — avval: --> <script src="js/alifbo.js"></script>
<script defer src="js/yaf-voice.js"></script>
```

- Ichki papkalardagi sahifalar uchun nisbiy yo‘lni to‘g‘rilang (`../js/yaf-voice.js`). Audio manzil baribir to‘g‘ri aniqlanadi.
- **`alifbo.js` qoidasi:**
  - sayt **eski** imloda bo‘lsa — **ulamang**, aks holda tugma yozuvlari (“Tinglash”, “Pauza”) yangi alifboga o‘tib qoladi;
  - sayt **yangi** alifboda bo‘lsa — **ulang**, chunki Edge’ning o‘zbek ovozi eski imloni to‘g‘ri o‘qiydi.
- SPA (React/Vue) bo‘lsa: skript sahifa mazmuni DOM’ga chiqqandan keyin yuklanishi kerak. Router bilan sahifa almashganda modul qayta ishga tushmaydi. Bunday holda har bir marshrutni alohida statik sahifa qilib eksport qilish (SSG) eng ishonchli yo‘l. Agar bu iloji bo‘lmasa, sahifa almashganda skriptni qayta yuklang: `window.__YAF_VOICE_LOADED = false` qilib, `<script>` ni qayta qo‘shing.

### 5.3. “Tinglash” tugmasi

Sahifa sarlavhasi blokiga (unda `position: relative` bo‘lsin yoki `yaf-hero-host` klassi berilsin) qo‘shing:

```html
<header class="page-hero yaf-hero-host">
  <div class="hero-tools">
    <button class="voice-btn" type="button" data-read="maqsad,nazariya,misol"
            title="Mavzuni ovozli tinglash" aria-label="Mavzuni ovozli tinglash">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
           stroke-linejoin="round" aria-hidden="true"><path d="M11 5 6 9H2v6h4l5 4V5z"/>
        <path d="M15.5 8.5a5 5 0 0 1 0 7M19 5a10 10 0 0 1 0 14"/></svg><span>Tinglash</span>
    </button>
  </div>
  <h1>Mavzu nomi</h1>
</header>
```

- `data-read` — o‘qiladigan bo‘limlarning **id lari**, o‘qish tartibida, vergul bilan. O‘qish `h1` sarlavhadan boshlanadi (`YAF_VOICE.title` bilan o‘zgartiriladi).
- **Har bir sahifada faqat bitta** `data-read` tugmasi bo‘ladi.
- Tavsiya etiladigan bo‘limlar:

| Sahifa turi | `data-read` (asl loyihadagi) | Izoh |
|---|---|---|
| Ma’ruza | `maqsad,reja,nazariya,misol,xatolar` | Test, adabiyot, prompt bloklari o‘qilmaydi |
| Amaliy mashg‘ulot | `maqsad,nazariy,ishlangan` | |
| Laboratoriya | `maqsad,nazariya,tartib,misol,xavfsizlik` | O‘lchash jadvallari, kalkulyatorlar va model o‘qilmaydi |

  Maqsadli loyihaning bo‘lim `id` lari boshqacha bo‘lsa, ularniki ishlatiladi. `id` bo‘lmasa — shablonga qo‘shiladi.
- Tugma hamma ma’ruza va laboratoriya sahifalarida bo‘lishi uchun uni **shablonga** qo‘shing. Generatorda bu bitta parametr: masalan, `hero(..., read="maqsad,nazariya")`.

### 5.4. Nima o‘qiladi va nima o‘qilmaydi

- **O‘qiladi:** belgilangan bo‘limlar ichidagi `h2, h3, p, li, tr, .katex-display`.
- **O‘tkazib yuboriladi:** `.sim-box, .quiz, .prompt-box, .tour-bar, .tour-cap, .vh, .no-read, .meas, .err-calc, .mnk-calc` ichidagi barcha narsa.
- **O‘qilmasin desangiz:** test, kod, jadval shabloni, “nusxalash” bloklariga **`no-read`** klassini qo‘ying yoki `YAF_VOICE.skip` ni kengaytiring.
- **Teg nomlari boshqacha bo‘lsa** (masalan, `.para`, `section > div`), `YAF_VOICE.blocks` ni moslang.

### 5.5. Formulalar

- **KaTeX:** qo‘shimcha ish kerak emas (`.katex annotation` dan TeX olinadi).
- **MathJax 3:** `mjx-container` qo‘llab-quvvatlanadi (TeX `MathJax.startup.document` dan yoki `data-tex` atributidan olinadi). Ko‘rgazmali formulalarni ham alohida xatboshi qilib o‘qitish uchun `YAF_VOICE.blocks` ga `mjx-container[display="true"]` ni qo‘shing.
- **MathJax 2:** `<script type="math/tex">` dan o‘qiladi.
- **Formula rasm bo‘lsa:** `alt` matni o‘qilmaydi. TeX’ni `<span class="no-read">` ichida qoldirib, yoniga o‘qiladigan matn yozing yoki rasmni KaTeX’ga almashtiring.
- **Matndagi indekslar:** `<sup>` daraja sifatida, `<sub>` indeks sifatida o‘qiladi. Unicode daraja belgilari (`10¹⁶`) ham tushuniladi.

### 5.6. Virtual laboratoriya: “Ovozli namoyish”

**HTML shartnomasi** (namunani `namuna-laboratoriya.html` da ko‘ring):

```html
<div class="sim-wrap">
  <div class="sim-box" data-sim="model-nomi"> … model … </div>
  <div class="tour-bar">
    <button class="voice-btn" type="button" data-tour="tour-lab3"> SVG <span>Ovozli namoyish</span></button>
  </div>
  <div class="tour-cap" aria-live="polite"></div>
  <ol class="vh tour-steps" id="tour-lab3">
    <li data-set='{"U": 6, "R": 20, "mode": "#0"}'>Kuchlanish 6 volt, qarshilik 20 om. Tok 0,3 amper.</li>
    <li data-set='{"U": 12}'>Kuchlanishni 12 voltga oshiramiz — tok ham ikki marta ortdi.</li>
    <li data-set='{"U": 6}'>Namoyish tugadi. Endi parametrlarni o‘zingiz o‘zgartiring.</li>
  </ol>
</div>
```

**Model uchun talablar:**

1. Har bir boshqaruv elementida **`data-k="kalit"`** bo‘lishi kerak: slayder uchun `<input type="range" data-k="U">`, tanlov uchun `<select data-k="mode">`. Model JS’da yaratilsa, `data-k` ni o‘sha kod qo‘shishi kerak.
2. Model `input` va `change` hodisalarida qayta chizilishi kerak. Namoyish slayderni silliq surib, `input` hodisasini yuboradi; tanlovda `change` yuboriladi.
3. Natijalar paneli `.readout` bo‘lsa, namoyish paytida yoritiladi (ixtiyoriy).
4. Model iframe ichida bo‘lsa (PhET), uning parametrlarini boshqarib bo‘lmaydi. Bunday holda `data-set='{}'` bilan faqat ovozli tushuntirish qiling.

**Ssenariy yozish qoidalari (har bir laboratoriya uchun):**

- 3–5 qadam: boshlang‘ich holat → bitta parametrni o‘zgartirish → yana bittasini o‘zgartirish → xulosa yoki boshlang‘ich qiymatlarga qaytish.
- Qiymatlar slayder chegarasida bo‘lsin. Tanlov uchun `"#indeks"` (`"#0"`, `"#1"`…) yoziladi.
- **Matndagi har bir son model ko‘rsatkichi bilan tekshirilgan bo‘lsin.** Avval qiymatni modelda o‘rnating, natijalar panelidan o‘qing, keyin yozing. Tushuntirishda sabab bo‘lsin, faqat raqam emas: “tok ikki marta ortdi, chunki…”.
- Sonlar vergul bilan yoziladi (`0,3`). Birliklar so‘z bilan yoki standart qisqartma bilan (`volt`, `V`) — ikkalasi ham to‘g‘ri o‘qiladi.
- Ssenariylarni ma’lumot faylida saqlash qulay (asl loyihada `gen/tours.py`: `{model: [(parametrlar, izoh), …]}`) va shablon `<ol>` ni shundan hosil qiladi.

### 5.7. MP3 generatsiyasi (GitHub Actions)

`.github/workflows/ovoz.yml` dagi `env` blokini sozlang:

| O‘zgaruvchi | Statik sayt | Yig‘iladigan sayt (Vite, Next, Docusaurus…) |
|---|---|---|
| `SITE_DIR` | `.` (yoki `docs`) | `dist` / `build` / `out` / `_site` |
| `AUDIO_DIR` | `audio/uz` (yoki `docs/audio/uz`) | `public/audio/uz` / `static/audio/uz` |
| `BUILD_CMD` | bo‘sh | `npm ci && npm run build` (va kerak bo‘lsa Node o‘rnatish qadami) |

**Asosiy shart:** `AUDIO_DIR` dagi fayllar nashr qilingan saytda **`<sayt ildizi>/audio/uz/`** manzilida chiqishi kerak. Boshqa manzil bo‘lsa, `YAF_VOICE.audioBase` ni sozlang.

**Repozitoriy sozlamalari:**

- Settings → Actions → General → Workflow permissions → **Read and write permissions**.
- Pages “GitHub Actions” rejimida nashr qilinsa: deploy workflow `audio/**` o‘zgarishida ham ishga tushishi kerak. Pages “branch” rejimida bo‘lsa, `ovoz.yml` dagi oxirgi qadam Pages’ni o‘zi yangilaydi.

**Ish tartibi:** sahifa matni o‘zgarib push qilinsa → workflow (5–30 daqiqa) → faqat o‘zgargan xatboshilar qayta ovozlanadi → `audio/uz/` commit qilinadi. Ovoz `uz-UZ-SardorNeural` (erkak). Ayol ovozi kerak bo‘lsa: Actions → “Ovoz (o‘zbekcha MP3)” → Run workflow → `uz-UZ-MadinaNeural` (barcha MP3 qayta yaratiladi).

**Hajm:** taxminan 1000 xatboshi ≈ 100–150 MB. Bu GitHub cheklovlari ichida. Juda katta darslikda (5000+ xatboshi) MP3’ni alohida `gh-pages` yoki `audio` branchida saqlash haqida o‘ylash kerak.

### 5.8. Sozlash (`window.YAF_VOICE`) — ixtiyoriy

`yaf-voice.js` dan **oldin** yoziladi:

```html
<script>
window.YAF_VOICE = {
  audioBase: 'audio/uz/',               // sayt ildiziga nisbatan yoki to‘liq URL
  root: '../',                          // yaf-voice.js dan sayt ildizigacha (standart '../' — js/ papkasi uchun)
  readButton: '.voice-btn[data-read]',
  title: '.page-hero h1, main h1, h1',
  blocks: 'h2, h3, p, li, tr, .katex-display',
  skip: '.sim-box,.quiz,.prompt-box,.tour-bar,.tour-cap,.vh,.no-read',
  lang: null,                           // 'uz' | 'ru' | 'en' (standart: data-tl → googtrans cookie → <html lang>)
  keep:  ['NaCl', 'DNK', 'PhET'],       // harfma-harf aytilmaydigan so‘zlar (kimyoviy formulalar, nomlar)
  multi: { pH: 'pe-ash' },              // maxsus talaffuz: belgi → aytilishi
  units: { mol: 'mol', 'g/mol': 'gramm mol ga' } // qo‘shimcha birliklar
};
</script>
```

**Fanga moslash.** Agar darslik fizikadan boshqa fanga oid bo‘lsa (kimyo, biologiya, informatika), `keep`, `multi` va `units` ni o‘sha fan atamalari bilan to‘ldiring. Shu bilan qisqartmalar to‘g‘ri aytiladi.

### 5.9. Dasturiy boshqaruv

`window.YAF_VOICE_API` quyidagilarni beradi:

- `stopAll()` — barcha ovozni to‘xtatish;
- `speak(matn)` — istalgan matnni o‘qitish;
- `lang`, `audioBase` — joriy qiymatlar.

Google Translate tili almashganda sahifa qayta yuklanadi, shuning uchun til avtomatik yangilanadi.

---

## 6. Tekshirish (majburiy)

1. **Mahalliy server:** `python3 -m http.server 8000`, so‘ng bitta ma’ruza va bitta laboratoriyani ochib ko‘ring:
   - “Tinglash” → ramka harakatlanadi;
   - pauza, davom, oldingi va keyingi tugmalari ishlaydi;
   - xatboshini bosganda “Shu yerdan o‘qish” chiqadi;
   - Esc o‘qishni to‘xtatadi;
   - “Ovozli namoyish” → slayderlar harakatlanadi, izoh chiqadi.
2. **Avtomatik tekshiruv:**
   ```bash
   pip install playwright && python -m playwright install chromium
   python tools/voice_check.py <SITE_DIR>
   ```
   **XATO 0** bo‘lishi shart: barcha `data-read` bo‘limlari topiladi, har sahifada o‘qiladigan matn bor, namoyish kalitlari va qiymatlari to‘g‘ri.
3. **Matnlar sifati:**
   ```bash
   python tools/tts_extract.py <SITE_DIR> /tmp/texts.json
   ```
   Natijadan 20–30 ta tasodifiy matnni ko‘zdan kechiring:
   - TeX qoldig‘i (`\frac`, `$$`) qolmaganmi;
   - qisqartmalar to‘g‘ri aytilyaptimi;
   - menyu, tugma va test matnlari kirib qolmaganmi.

   Kerak bo‘lsa, `keep`, `multi`, `units`, `skip` ni sozlang.
4. **Push qilgandan keyin:** Actions’da “Ovoz (o‘zbekcha MP3)” yashil bo‘lishi va oxirida `Tayyor: yangi N, xato 0` chiqishi kerak. So‘ng nashr qilingan saytda o‘zbekcha ovoz MP3 orqali ijro etilishini tekshiring: DevTools → Network → `.mp3`.

---

## 7. Tez-tez uchraydigan muammolar

| Belgi | Sabab | Yechim |
|---|---|---|
| Ovoz turkcha yoki “robot” kabi eshitiladi | MP3 topilmadi (manifest yo‘q yoki noto‘g‘ri manzil) | `YAF_VOICE_API.audioBase` ni konsolda tekshiring. `<ildiz>/audio/uz/manifest.json` brauzerda ochilishi kerak. |
| MP3 bor, lekin ba’zi xatboshilar brauzer ovozida o‘qiladi | Sahifa matni o‘zgargan, workflow hali tugamagan yoki ishga tushmagan | Actions’ni tekshiring; `paths-ignore` sahifa fayllarini chiqarib yubormasligi kerak. |
| Workflow: `yaf-voice.js ulanmagan, o‘tkazib yuborildi` | Skript sahifaga qo‘shilmagan yoki `SITE_DIR` noto‘g‘ri | Shablonni va `SITE_DIR` ni tekshiring. |
| Workflow push qila olmaydi (403) | Actions’ga yozish huquqi yo‘q | Settings → Actions → Read and write. |
| Tugma yozuvlari “Tinglaş”, “Şu yerdan” bo‘lib qoldi | Eski imlodagi saytga `alifbo.js` ulangan | `alifbo.js` ni olib tashlang. |
| Namoyishda slayder harakatlanmaydi | `data-k` yo‘q yoki model `input` hodisasini tinglamaydi | 5.6-band; `voice_check.py` xatoni ko‘rsatadi. |
| Formulalar o‘qilmaydi yoki “belgi-belgi” o‘qiladi | KaTeX MathML o‘chirilgan (`output:'html'`) yoki formula rasm | `output` ni standartga qaytaring; 5.5-band. |
| Test yoki menyu ham o‘qilyapti | Bo‘lim ichida joylashgan | `no-read` klassi yoki `skip`. |
| Telefonda birinchi bosishda ovoz chiqmaydi | iOS avtoijro cheklovi | Tugma bosilganda ijro boshlanadi (tizim shunday qurilgan). Qayta bosib ko‘ring. |

---

## 8. Eslatmalar

- `edge-tts` — Microsoft Edge “Read aloud” xizmatining norasmiy mijozi. U bepul va kalitsiz ishlaydi, lekin Microsoft uni istalgan vaqtda o‘zgartirishi mumkin. Tayyor MP3’lar repozitoriyda qolgani uchun sayt bundan zarar ko‘rmaydi: faqat yangi matnlarni ovozlash to‘xtashi mumkin.
- Kod CC BY-SA 4.0 litsenziyasida. Asl muallif: I.M. Eshboltayev (QDU).
