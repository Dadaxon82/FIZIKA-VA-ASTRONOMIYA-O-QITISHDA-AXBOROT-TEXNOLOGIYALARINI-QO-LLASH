# Claude Code uchun prompt — ovozli tizimni joriy etish

## Tayyorgarlik (siz bajarasiz, 2 daqiqa)

1. `yaf-voice-kit.zip` ni maqsadli darslik repozitoriyasining **ildiziga** oching. Natijada `_yaf-voice-kit/` papkasi paydo bo‘ladi.
2. Shu repozitoriyda Claude Code’ni ishga tushiring. Bu terminal, Claude desktop ilovasi yoki claude.ai/code bo‘lishi mumkin.
3. Quyidagi promptni to‘liq nusxalab yuboring. Kvadrat qavsdagi joylarni to‘ldiring yoki o‘chirib tashlang.

---

## Prompt (nusxalang)

```text
Vazifa: shu repozitoriydagi elektron darslikka "YAF Voice" ovozli tizimini joriy et. Tizim BARCHA ma’ruza va
laboratoriya (bo‘lsa, amaliy mashg‘ulot) sahifalarida xuddi asl loyihadagidek ishlashi kerak. Asl loyihalar:
https://github.com/eshboltayev/Yarimo-tkazgich_asboblar_fizikasi
https://github.com/eshboltayev/Fizpraktikum

Barcha kod va to‘liq yo‘riqnoma _yaf-voice-kit/ papkasida. ENG AVVAL _yaf-voice-kit/INTEGRATSIYA.md ni boshidan
oxirigacha o‘qi va unga qat’iy amal qil. Ishlaydigan namunalar: _yaf-voice-kit/namuna-maruza.html va
_yaf-voice-kit/namuna-laboratoriya.html (+ js/namuna-model.js).

Natijada quyidagilar ishlashi shart:
1. Har bir ma’ruza va laboratoriya sahifasi sarlavhasida "Tinglash" tugmasi bo‘lsin. U sahifani xatboshma-xatboshi
   o‘qiydi, o‘qilayotgan joy ramka bilan belgilanadi. Pastda panel chiqadi: pauza/davom, oldingi/keyingi,
   to‘xtatish. Xatboshini bosganda "Shu yerdan o‘qish" chiqadi; Esc o‘qishni to‘xtatadi.
2. O‘zbek tilida ovoz oldindan tayyorlangan neyron MP3 dan ijro etilsin. MP3 lar GitHub Actions
   (.github/workflows/ovoz.yml, edge-tts) orqali avtomatik yaratiladi; API kalit ishlatilmaydi. RU/EN da
   brauzer ovozi ishlatiladi.
3. Formulalar (KaTeX/MathJax) odam o‘qiganidek so‘z bilan o‘qilsin.
4. Har bir virtual laboratoriya (interaktiv model) yonida "Ovozli namoyish" tugmasi bo‘lsin. U model
   parametrlarini o‘zi silliq o‘zgartirib, har bir qadamni o‘zbek tilida tushuntiradi, keyin boshqaruvni
   talabaga beradi.

Ish tartibi:
A) TAHLIL. INTEGRATSIYA.md ning 4-bo‘limi bo‘yicha loyihani o‘rgan:
   - sayt qanday quriladi va qaysi shablon/fayl ma’ruza, laboratoriya, amaliy sahifalarni hosil qiladi;
   - nashr qilinadigan papka (SITE_DIR) va MP3 papkasi (AUDIO_DIR) qayer bo‘ladi;
   - formulalar qaysi vosita bilan chiqadi;
   - matnlar qaysi alifboda (eski yoki yangi);
   - bo‘limlar id lari va qaysilari o‘qilishi kerak;
   - virtual laboratoriyalar qanday qurilgan, boshqaruv elementlari qayerda yaratiladi;
   - konflikt bo‘lishi mumkin bo‘lgan klasslar yoki mavjud ovoz kodi.
   Menga qisqa reja yoz: qaysi fayllar o‘zgaradi, data-read qiymatlari, SITE_DIR/AUDIO_DIR/BUILD_CMD,
   nechta model namoyish oladi. Reja aniq bo‘lsa, so‘ramasdan davom et. Faqat qaytarib bo‘lmaydigan yoki
   ikki xil talqin qilinadigan qarorlarda so‘ra.
B) KO‘CHIRISH VA ULASH (5.1–5.5-bandlar). O‘zgarishlarni SHABLON yoki GENERATORga kirit; yaratilgan HTML ni
   qo‘lda tahrirlama (generator bo‘lsa, uni qayta ishga tushir). css/yaf-voice.css ranglarini sayt
   dizayniga moslab, tugmani sarlavhaga chiroyli joylashtir; qorong‘i/yorug‘ rejim va telefonda ham chiroyli
   ko‘rinsin. alifbo.js qoidasiga amal qil. Test, adabiyot, kod, jadval shablonlari o‘qilmasin (no-read/skip).
   Darslik fanining atamalari uchun YAF_VOICE.keep/multi/units ni to‘ldir.
C) NAMOYISHLAR (5.6-band). Har bir model kodini o‘qib, boshqaruv elementlariga data-k qo‘sh. So‘ng har bir
   laboratoriya uchun 3–5 qadamli ssenariy yoz:
   - har bir qiymatni avval modelda o‘rnat, natijalar panelidan o‘qi, faqat shundan keyin matnga yoz —
     to‘qilgan son bo‘lmasin;
   - tushuntirish fizik sababni aytsin;
   - oxirgi qadam parametrlarni boshlang‘ich holatga qaytarsin.
   Ssenariylarni alohida ma’lumot faylida saqla, <ol class="tour-steps"> shablon orqali hosil bo‘lsin.
   Iframe modellarida faqat ovozli tushuntirish qil (data-set='{}').
D) GITHUB ACTIONS (5.7-band). .github/workflows/ovoz.yml ni ko‘chirib, env ni sozla. Sayt yig‘iladigan bo‘lsa,
   Node o‘rnatish va BUILD_CMD ni qo‘sh. AUDIO_DIR nashr qilinganda sayt ildizida audio/uz/ bo‘lib chiqishini
   ta’minla (yoki YAF_VOICE.audioBase ni sozla). Pages deploy workflow bo‘lsa, audio o‘zgarganda ham
   ishlashini tekshir.
E) TEKSHIRISH (6-bo‘lim):
   - python tools/voice_check.py <SITE_DIR> — XATO 0 bo‘lishi shart;
   - python tools/tts_extract.py <SITE_DIR> /tmp/texts.json — kamida 30 ta matnni ko‘zdan kechir: TeX qoldig‘i,
     noto‘g‘ri aytilgan qisqartma, o‘qilib qolgan menyu yoki test matni yo‘qligiga ishonch hosil qil va
     tuzat;
   - mahalliy serverda bitta ma’ruza va bitta laboratoriyani headless brauzerda och: JS xatosi yo‘q;
     tugma → panel chiqadi; pauza/davom ishlaydi; namoyishda slayderlar harakatlanadi;
   - telefon (390 px) va katta ekran (1920 px) da tugma va panel sig‘adi.
F) YAKUNLASH:
   - _yaf-voice-kit/ papkasini repozitoriydan o‘chir (yoki nashrdan chiqarib tashla), README ga "Ovozli
     o‘qish" bo‘limini qo‘sh;
   - tushunarli commit qil va main ga push qil;
   - Actions’da "Ovoz (o‘zbekcha MP3)" ish oqimi tugashini kut va oxirida "Tayyor: yangi N, xato 0"
     chiqqanini tekshir. Workflow yozish huquqi yo‘qligi sababli yiqilsa, menga Settings → Actions →
     Workflow permissions → Read and write ni yoqishni ayt.

Yakuniy hisobotda yoz:
- nechta ma’ruza, laboratoriya va amaliy sahifaga tugma qo‘shildi;
- nechta modelga namoyish qo‘shildi;
- qaysi fayllar o‘zgardi;
- voice_check natijasi;
- nechta MP3 yaratildi;
- men qo‘lda nima qilishim kerak (masalan, Pages yoki Actions sozlamalari).

[Ixtiyoriy qo‘shimcha talablar: masalan, "ovoz ayol bo‘lsin — uz-UZ-MadinaNeural",
"amaliy mashg‘ulotlarda faqat maqsad va ishlangan misol o‘qilsin" va hokazo.]
```

---

## Maslahatlar

- **Uzoq ish.** Yirik darslikda (30+ sahifa, 15+ model) agent bir necha bosqichda ishlaydi. Oraliq natijalarni ko‘rib, yo‘nalish berib turing.
- **Ishni bo‘lish.** Agar agent kontekst yetishmasligidan to‘xtab qolsa, ishni ikki promptga bo‘ling: birinchisida A–B va D bosqichlari (tugma va MP3), ikkinchisida C bosqichi (namoyishlar). Ikkinchi promptni “INTEGRATSIYA.md ning 5.6-bandi bo‘yicha barcha modellarga ovozli namoyish qo‘sh” deb boshlang.
- **Tekshirish.** Ishdan so‘ng sayt manzilini telefon va o‘qituvchi kompyuterida (Chrome) ochib, “Tinglash” ni sinab ko‘ring. Ovoz har ikkisida bir xil, tabiiy bo‘lishi kerak.
