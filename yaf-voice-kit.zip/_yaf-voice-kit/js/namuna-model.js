/* Namuna virtual laboratoriya (Om qonuni). Ovoz moduli bilan ishlash SHARTNOMASI:
 *  1) Model ildizi: <div class="sim-box">.
 *  2) Har bir boshqaruv elementida data-k="parametr_kaliti" bo'lishi kerak:
 *       slayder  — <input type="range" data-k="R">  (namoyish "input" hodisasini yuboradi)
 *       tanlov   — <select data-k="mode">             (namoyish "change" hodisasini yuboradi, qiymat "#indeks")
 *  3) Model "input"/"change" hodisalarida qayta chizilishi kerak.
 *  4) Natijalar paneli (ixtiyoriy): .readout — namoyish paytida yoritiladi.
 * Sizning loyihangizdagi har qanday model shu shartnomaga moslansa, ovozli namoyish ishlaydi. */
(() => {
  document.querySelectorAll('.sim-box[data-sim="namuna-om"]').forEach(box => {
    box.innerHTML = `
      <label>Kuchlanish U, V: <b data-o="U"></b><input type="range" data-k="U" min="0" max="12" step="0.1" value="6"></label>
      <label>Qarshilik R, Om: <b data-o="R"></b><input type="range" data-k="R" min="1" max="100" step="1" value="20"></label>
      <label>Material <select data-k="mat"><option>Mis</option><option>Nixrom</option></select></label>
      <canvas width="560" height="200" style="width:100%;max-width:560px;background:#0b1220;border-radius:10px"></canvas>
      <div class="readout"></div>`;
    const cv = box.querySelector('canvas'), c = cv.getContext('2d'), ro = box.querySelector('.readout');
    const draw = () => {
      const U = +box.querySelector('[data-k="U"]').value, R = +box.querySelector('[data-k="R"]').value, I = U / R;
      box.querySelector('[data-o="U"]').textContent = U.toFixed(1); box.querySelector('[data-o="R"]').textContent = R;
      c.clearRect(0, 0, 560, 200); c.strokeStyle = '#334155'; c.strokeRect(40, 10, 500, 170);
      c.strokeStyle = '#22d3ee'; c.lineWidth = 2; c.beginPath(); c.moveTo(40, 180); c.lineTo(540, 180 - 170 * Math.min(1, (12 / R) / 1.2)); c.stroke();
      c.fillStyle = '#fbbf24'; c.beginPath(); c.arc(40 + 500 * U / 12, 180 - 170 * Math.min(1, I / 1.2), 6, 0, 7); c.fill();
      ro.innerHTML = `<span>Tok I = U/R</span> <b>${I.toFixed(3).replace('.', ',')} A</b> · <span>Quvvat P</span> <b>${(U * I).toFixed(2).replace('.', ',')} W</b>`;
    };
    box.addEventListener('input', draw); box.addEventListener('change', draw); draw();
  });
})();
